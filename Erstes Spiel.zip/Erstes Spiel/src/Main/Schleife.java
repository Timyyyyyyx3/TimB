
package Main;

public class Schleife {
    
    
    public static void main(String[] args) {
        
        initialisieren();
        
        while(true){
            berechnen();
            
            
            draw();
            
        }
         
    }

    private static void initialisieren() {
        throw new UnsupportedOperationException("Not supported yet.");}

    private static void berechnen() {
        throw new UnsupportedOperationException("Not supported yet.");}

    private static void draw() {
        throw new UnsupportedOperationException("Not supported yet.");}

}